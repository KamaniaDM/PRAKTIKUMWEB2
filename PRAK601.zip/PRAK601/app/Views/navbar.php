<nav>
    <ul>
        <li><a href="<?= base_url('/') ?>">Beranda</a></li>
        <li><a href="<?= base_url('profil') ?>">Profil</a></li>
    </ul>
</nav>